import { useEffect, useState } from 'react'
import { rpc, type HistoryRow } from '../../lib/api'
import { ago, money } from '../../lib/format'
import { cn } from '../../lib/cn'

export default function RiderHistory() {
  const [rows, setRows] = useState<HistoryRow[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  useEffect(() => {
    rpc<HistoryRow[]>('rider_my_history').then(setRows).catch((e) => setError(e instanceof Error ? e.message : 'Could not load'))
  }, [])
  const done = (rows ?? []).filter((r) => r.job_status === 'delivered').length

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-ink-900">History</h1>
      {rows && <p className="text-sm text-slate-600">{done} delivered</p>}
      {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
      {rows && rows.length === 0 && <p className="rounded-2xl bg-white p-5 text-sm text-slate-600 ring-1 ring-slate-200">No finished deliveries yet.</p>}
      <ul className="space-y-3">
        {(rows ?? []).map((r) => (
          <li key={r.job_id} className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
            <div className="flex items-center justify-between">
              <p className="font-bold text-slate-800">Order #{r.order_no}</p>
              <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-semibold', r.job_status === 'delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-700')}>
                {r.job_status === 'delivered' ? 'Delivered' : 'Failed'}
              </span>
            </div>
            <p className="mt-1 text-sm text-slate-600">{r.shop_name} · {ago(r.finished_at)}</p>
            <p className="text-sm text-slate-500">{r.address}</p>
            <p className="mt-1 text-sm text-slate-700">Order {money(r.total)} · Fee {money(r.delivery_fee)}</p>
          </li>
        ))}
      </ul>
      <p className="text-center text-xs text-slate-500">Earnings and settlements arrive in the next batch.</p>
    </div>
  )
}
